//
//  FileHolder.h
//  KiiSDK-Private
//
//  Created by Syah Riza on 8/7/13.
//  Copyright (c) 2013 Kii Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FileHolder <NSObject>

@end
