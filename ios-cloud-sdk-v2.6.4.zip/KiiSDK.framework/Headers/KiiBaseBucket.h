//
//  KiiBaseBucket.h
//  KiiSDK-Private
//
//  Created by Syah Riza on 5/20/13.
//  Copyright (c) 2013 Kii Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

/** Base Class of KiiBucket
 */
@interface KiiBaseBucket : NSObject

@end
