//
//  KAConstants.h
//  KiiAnalytics
//
//  Created by Ryuji OCHI on 6/17/13.
//  Copyright (c) 2013 Kii Corporation. All rights reserved.
//

/** Error domain name prefix for KiiAnalytics related errors */
static NSString * const kErrorDomainNamePrefix = @"com.kii.analytics";
